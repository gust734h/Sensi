package com.pocoboost

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.util.TypedValue
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*

/** Uma otimização: comandos para ligar e comandos para desfazer. */
data class Tweak(val title: String, val desc: String, val on: List<String>, val off: List<String>)

class MainActivity : Activity() {

    private val games = listOf("com.dts.freefireth", "com.dts.freefiremax")
    private lateinit var status: TextView
    private lateinit var root: LinearLayout
    private val prefs by lazy { getSharedPreferences("boost", Context.MODE_PRIVATE) }

    private fun tweaks(): List<Tweak> {
        val g = games
        return listOf(
            Tweak("Animações 0,5x", "Interface mais rápida (3 escalas)",
                listOf("window_animation_scale", "transition_animation_scale", "animator_duration_scale")
                    .map { "settings put global $it 0.5" },
                listOf("window_animation_scale", "transition_animation_scale", "animator_duration_scale")
                    .map { "settings put global $it 1.0" }),
            Tweak("Animações desligadas", "Máxima rapidez visual",
                listOf("window_animation_scale", "transition_animation_scale", "animator_duration_scale")
                    .map { "settings put global $it 0" },
                listOf("window_animation_scale", "transition_animation_scale", "animator_duration_scale")
                    .map { "settings put global $it 1.0" }),
            Tweak("Tela fixa em 120 Hz", "Mais fluidez e resposta ao toque",
                listOf("settings put system peak_refresh_rate 120.0", "settings put system min_refresh_rate 120.0"),
                listOf("settings delete system min_refresh_rate", "settings put system peak_refresh_rate 120.0")),
            Tweak("DNS privado (Google)", "Resolução de nomes mais rápida",
                listOf("settings put global private_dns_mode hostname", "settings put global private_dns_specifier dns.google"),
                listOf("settings put global private_dns_mode opportunistic")),
            Tweak("DNS privado (Cloudflare)", "Alternativa ao Google (desative o outro)",
                listOf("settings put global private_dns_mode hostname", "settings put global private_dns_specifier one.one.one.one"),
                listOf("settings put global private_dns_mode opportunistic")),
            Tweak("Wi-Fi baixa latência", "Reduz ping no Wi-Fi (Android 13+)",
                listOf("cmd wifi force-low-latency-mode enabled", "cmd wifi force-hi-perf-mode enabled"),
                listOf("cmd wifi force-low-latency-mode disabled", "cmd wifi force-hi-perf-mode disabled")),
            Tweak("Modo Jogo: Desempenho", "Free Fire e Free Fire MAX em modo desempenho",
                g.map { "cmd game mode performance $it" }, g.map { "cmd game mode standard $it" }),
            Tweak("Free Fire sem economia de bateria", "Evita que o sistema limite o jogo",
                g.map { "cmd deviceidle whitelist +$it" }, g.map { "cmd deviceidle whitelist -$it" }),
            Tweak("Desligar bateria adaptável", "Sem limitação automática de apps",
                listOf("settings put global adaptive_battery_management_enabled 0"),
                listOf("settings put global adaptive_battery_management_enabled 1")),
            Tweak("Não perturbe", "Bloqueia notificações durante a partida",
                listOf("cmd notification set_dnd priority"), listOf("cmd notification set_dnd off")),
            Tweak("Compilar jogo (speed)", "Pré-compila o app para abrir/rodar mais rápido",
                g.map { "cmd package compile -m speed -f $it" }, emptyList()),
            Tweak("Desligar Wi-Fi scan constante", "Menos picos de latência por busca de redes",
                listOf("settings put global wifi_scan_always_enabled 0", "settings put global ble_scan_always_enabled 0"),
                listOf("settings put global wifi_scan_always_enabled 1", "settings put global ble_scan_always_enabled 1"))
        )
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val scroll = ScrollView(this).apply { setBackgroundColor(Color.parseColor("#101114")) }
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(32), dp(16), dp(24)) }
        scroll.addView(root)
        setContentView(scroll)
        build()
    }

    override fun onResume() { super.onResume(); refreshStatus() }

    private fun build() {
        root.addView(text("Poco Boost", 26f, Color.WHITE, true))
        root.addView(text("Otimização do sistema para o Poco F7. Não altera o jogo nem a mira.", 13f, Color.GRAY))
        status = text("", 14f, Color.YELLOW).apply { setPadding(0, dp(12), 0, dp(4)) }
        root.addView(status)
        root.addView(button("Conceder permissão Shizuku") { Shell.request(); refreshStatus() })

        root.addView(section("Atalhos"))
        root.addView(button("🚀 MODO JOGO (aplica tudo recomendado + hiberna apps)") { gameMode() })
        root.addView(button("Limpar RAM (apps em cache)") { run("Limpar RAM", listOf("am kill-all")) })
        root.addView(button("Limpar caches de apps") { run("Limpar caches", listOf("pm trim-caches 4G")) })
        root.addView(button("↩ Restaurar tudo") { restoreAll() })

        root.addView(section("Otimizações"))
        tweaks().forEach { t ->
            val sw = Switch(this).apply {
                text = "${t.title}\n${t.desc}"
                setTextColor(Color.WHITE)
                isChecked = prefs.getBoolean(t.title, false)
                setPadding(0, dp(10), 0, dp(10))
                setOnCheckedChangeListener { _, on ->
                    prefs.edit().putBoolean(t.title, on).apply()
                    run(t.title, if (on) t.on else t.off)
                }
            }
            root.addView(sw)
        }

        root.addView(section("Hibernar apps (estilo Brevent)"))
        root.addView(text("Marque os apps que serão parados antes de jogar.", 12f, Color.GRAY))
        val selected = prefs.getStringSet("hib", emptySet())!!.toMutableSet()
        val pm = packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        pm.queryIntentActivities(launcher, 0)
            .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .distinctBy { it.first }
            .filter { it.first != packageName && it.first !in games }
            .sortedBy { it.second.lowercase() }
            .forEach { (pkg, label) ->
                root.addView(CheckBox(this).apply {
                    text = label; setTextColor(Color.WHITE)
                    isChecked = pkg in selected
                    setOnCheckedChangeListener { _, c ->
                        if (c) selected.add(pkg) else selected.remove(pkg)
                        prefs.edit().putStringSet("hib", selected.toSet()).apply()
                    }
                })
            }
        root.addView(button("Hibernar selecionados agora") { hibernate() })
        root.addView(button("Liberar apps hibernados") { unhibernate() })
    }

    private fun hibernate() {
        val list = prefs.getStringSet("hib", emptySet())!!
        run("Hibernar", list.flatMap { listOf("cmd appops set $it RUN_IN_BACKGROUND ignore", "am force-stop $it") })
    }

    private fun unhibernate() {
        val list = prefs.getStringSet("hib", emptySet())!!
        run("Liberar", list.map { "cmd appops set $it RUN_IN_BACKGROUND allow" })
    }

    private fun gameMode() {
        val recommended = setOf(
            "Animações 0,5x", "Tela fixa em 120 Hz", "DNS privado (Google)", "Wi-Fi baixa latência",
            "Modo Jogo: Desempenho", "Free Fire sem economia de bateria", "Não perturbe",
            "Desligar Wi-Fi scan constante"
        )
        val cmds = tweaks().filter { it.title in recommended }.flatMap { it.on }.toMutableList()
        recommended.forEach { prefs.edit().putBoolean(it, true).apply() }
        cmds += prefs.getStringSet("hib", emptySet())!!.flatMap {
            listOf("cmd appops set $it RUN_IN_BACKGROUND ignore", "am force-stop $it")
        }
        cmds += "am kill-all"
        run("Modo Jogo", cmds)
        recreateUi()
    }

    private fun restoreAll() {
        val cmds = tweaks().flatMap { it.off } +
            prefs.getStringSet("hib", emptySet())!!.map { "cmd appops set $it RUN_IN_BACKGROUND allow" }
        tweaks().forEach { prefs.edit().putBoolean(it.title, false).apply() }
        run("Restaurar", cmds)
        recreateUi()
    }

    private fun recreateUi() { root.removeAllViews(); build(); refreshStatus() }

    private fun run(name: String, cmds: List<String>) {
        if (!Shell.granted()) { toast("Ative o Shizuku e conceda a permissão"); return }
        Thread {
            val results = cmds.map { Shell.run(it) }
            val errors = results.count { it.startsWith("Erro") || it.contains("Exception") }
            runOnUiThread { toast(if (errors == 0) "$name: aplicado ✔" else "$name: $errors comando(s) falharam") }
        }.start()
    }

    private fun refreshStatus() {
        status.text = when {
            !Shell.running() -> "⚠ Shizuku não está em execução. Abra o app Shizuku e inicie via Depuração sem fio."
            !Shell.granted() -> "⚠ Falta conceder permissão ao Poco Boost."
            else -> "✔ Shizuku ativo e autorizado"
        }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    private fun dp(v: Int) = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics).toInt()
    private fun section(t: String) = text(t, 18f, Color.parseColor("#FF8A3D"), true).apply { setPadding(0, dp(22), 0, dp(6)) }
    private fun text(t: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = size; setTextColor(color); if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
    }
    private fun button(t: String, click: () -> Unit) = Button(this).apply {
        text = t; isAllCaps = false; setOnClickListener { click() }
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
    }
}
